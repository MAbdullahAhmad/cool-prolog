document.addEventListener('DOMContentLoaded', () => {
  const workspace = document.getElementById('workspace');
  const createCellButton = document.getElementById('createCell');

  createCellButton.addEventListener('click', () => {
      const cell = createCell();
      workspace.insertBefore(cell, createCellButton);
      cell.querySelector('.cell-input').focus();
  });
});

function executePrologCode(textArea, outputDiv) {
    const prologCode = textArea.value;

    fetch('http://localhost:3005/api/exec', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ prologCode })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            outputDiv.textContent = data.error;
            outputDiv.className = 'cell-output output-error'; // Apply error styling
        } else {
            // Aggregate results from the array and display them
            const allResults = data.results.map(result => result.result || result.error).join('\n');
            outputDiv.textContent = allResults;
            outputDiv.className = 'cell-output output-success'; // Apply success styling
        }
    })
    .catch(error => {
        outputDiv.textContent = 'Error: ' + error.message;
        outputDiv.className = 'cell-output output-error'; // Apply error styling
    });
}



function createCell() {
  const cell = document.createElement('div');
  cell.className = 'cell';

  const textArea = document.createElement('textarea');
  textArea.className = 'cell-input';
  cell.appendChild(textArea);

  const controlsDiv = document.createElement('div');
  controlsDiv.className = 'cell-controls';

  const runButton = document.createElement('button');
  runButton.className = 'control-button run';
  runButton.innerHTML = '<i class="fas fa-play"></i>'; // Font Awesome play icon
  controlsDiv.appendChild(runButton);

  const deleteButton = document.createElement('button');
  deleteButton.className = 'control-button delete';
  deleteButton.innerHTML = '<i class="fas fa-trash"></i>'; // Font Awesome trash icon
  controlsDiv.appendChild(deleteButton);

  const outputDiv = document.createElement('div');
  outputDiv.className = 'cell-output';

  runButton.onclick = () => executePrologCode(textArea, outputDiv);

  deleteButton.onclick = () => cell.remove();

  cell.appendChild(controlsDiv);
  cell.appendChild(outputDiv);

  return cell;
}
