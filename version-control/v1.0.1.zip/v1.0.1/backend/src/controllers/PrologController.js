const CoolPrologManager = require('../classes/CoolPrologManager');

const PrologController = {
  sync: (req, res) => {
    res.json({ success: true });
  },

  exec: (req, res) => {
    const prologManager = new CoolPrologManager(req.sessionID);
    prologManager.runPrologCode(req.body.prologCode, (results) => {
      if (results.error) {
        res.status(500).json(results);
      } else {
        res.json({ results });
      }
    });
  }
};

module.exports = PrologController;
