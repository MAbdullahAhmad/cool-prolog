% Facts and rules
parent(alice, bob).
parent(bob, charlie).
child(X, Y) :- parent(Y, X).

% Queries denoted with %? at the beginning
%? child(Who, alice).
%? child(charlie, bob).
