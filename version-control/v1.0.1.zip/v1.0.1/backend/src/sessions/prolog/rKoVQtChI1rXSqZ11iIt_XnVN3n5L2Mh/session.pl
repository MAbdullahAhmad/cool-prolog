% Facts defining family relationships
parent(alice, bob).   % Alice is a parent of Bob
parent(alice, lisa).  % Alice is also a parent of Lisa
parent(john, bob).    % John is a parent of Bob
parent(john, lisa).   % John is also a parent of Lisa

% Rules to determine relationships based on the facts above
child(X, Y) :- parent(Y, X). % X is a child of Y if Y is a parent of X

sibling(X, Y) :-          % X is a sibling of Y if
    parent(Z, X),        % Z is a parent of X and
    parent(Z, Y),        % Z is also a parent of Y and
    X \= Y.              % X and Y are not the same person

% Queries you can test
% parent(alice, Who).
% child(bob, Who).
% sibling(bob, Who).
