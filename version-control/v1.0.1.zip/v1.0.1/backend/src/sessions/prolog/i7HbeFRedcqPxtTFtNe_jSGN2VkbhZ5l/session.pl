% Facts
male(john).
male(alex).

parent(john, alex).
father(F, C) :- male(F), parent(F, C).

%? father(john, Child).
