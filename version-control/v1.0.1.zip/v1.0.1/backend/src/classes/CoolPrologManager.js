const fs = require('fs');
const path = require('path');
const pl = require('tau-prolog');

class CoolPrologManager {
  constructor(sessionId) {
    this.sessionDirectory = path.join(__dirname, '..', 'sessions', 'prolog', sessionId);
    fs.mkdirSync(this.sessionDirectory, { recursive: true });
    this.prologFilePath = path.join(this.sessionDirectory, 'session.pl');
    this.session = pl.create(1000);
  }

  writeToFile(prologCode) {
    fs.writeFileSync(this.prologFilePath, prologCode);
  }

  separateCodeAndQueries() {
    const fileContent = fs.readFileSync(this.prologFilePath, { encoding: 'utf-8' });
    const lines = fileContent.split('\n');
    return {
      program: lines.filter(line => !line.trim().startsWith('%?')).join('\n'),
      queries: lines.filter(line => line.trim().startsWith('%?')).map(line => line.replace('%?', '').trim())
    };
  }

  executeQueries(queries, callback) {
    let index = 0;
    let results = [];

    const processQuery = () => {
      if (index < queries.length) {
        this.session.query(queries[index], {
          success: () => {
            this.session.answer(answer => {
              if (answer instanceof pl.type.Term && answer.indicator === "throw/1") {
                // If the answer is an error
                results.push({ error: pl.format_answer(answer) });
              } else {
                // If the answer is successful
                results.push({ result: pl.format_answer(answer) });
              }

              index++;
              if (index < queries.length) {
                processQuery(); // Process the next query
              } else {
                callback(results); // No more queries, return the results
              }
            });
          },
          error: err => {
            results.push({ error: err.toString() });
            index++;
            processQuery();
          }
        });
      } else {
        callback(results); // Callback with the results
      }
    };

    processQuery();
  }


  runPrologCode(prologCode, callback) {
    this.writeToFile(prologCode);
    const { program, queries } = this.separateCodeAndQueries();
    this.session.consult(program, {
      success: () => this.executeQueries(queries, callback),
      error: err => callback({ error: err.toString() })
    });
  }
}

module.exports = CoolPrologManager;
